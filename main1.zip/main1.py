# -*- coding: utf-8 -*-
import argparse
import calendar
import os
import zipfile
from io import BytesIO
from datetime import datetime, date
from urllib.parse import urljoin
import time
import random
from threading import Lock
from concurrent.futures import ThreadPoolExecutor
import sys
import json

import requests
from requests.adapters import HTTPAdapter
from urllib3.poolmanager import PoolManager
import ssl
from bs4 import BeautifulSoup
from PIL import Image
import pytesseract

# Tesseract setup
pytesseract.pytesseract.tesseract_cmd = r"C:\\Users\\dhi_intern4\\AppData\\Local\\Programs\\Tesseract-OCR\\tesseract.exe"

# Constants
BASE_URL = "https://bidhannagarcitypolice.gov.in"
FIR_DOWNLOAD_URL = BASE_URL + "/fir_record.php"
SEARCH_URL = FIR_DOWNLOAD_URL
HEADERS = {"User-Agent": "Mozilla/5.0"}

class SessionWrapper:
    def __init__(self):
        self.session = requests.Session()

def simulate_human_delay(min_delay=1.5, max_delay=3.5):
    time.sleep(random.uniform(min_delay, max_delay))

def safe_get(wrapper, url, headers=None, params=None, max_retries=3, timeout=10):
    for attempt in range(max_retries):
        try:
            response = wrapper.session.get(url, headers=headers, params=params, timeout=timeout)
            response.raise_for_status()
            simulate_human_delay()
            return response
        except (SSLError, ConnectionError, IncompleteRead, RemoteDisconnected, ProtocolError, RequestException) as e:
            print(f"[GET] Attempt {attempt+1} failed: {e}")
            wrapper.session = requests.Session()  # Reinitialize session
            time.sleep(2 ** attempt + random.uniform(0, 0.5))
    raise RuntimeError(f"[GET] Failed to fetch {url} after {max_retries} attempts")

def safe_post(wrapper, url, data=None, headers=None, max_retries=3, timeout=10):
    for attempt in range(max_retries):
        try:
            response = wrapper.session.post(url, data=data, headers=headers, timeout=timeout)
            response.raise_for_status()
            simulate_human_delay()
            return response
        except (SSLError, ConnectionError, IncompleteRead, RemoteDisconnected, ProtocolError, RequestException) as e:
            print(f"[POST] Attempt {attempt+1} failed: {e}")
            wrapper.session = requests.Session()
            time.sleep(2 ** attempt + random.uniform(0, 0.5))
    raise RuntimeError(f"[POST] Failed to post to {url} after {max_retries} attempts")

def load_or_create_ps_map(wrapper, zip_path):
    """Load police station map from ZIP or website."""
    if zip_path and os.path.exists(zip_path):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                if "ps_map.json" in zipf.namelist():
                    with zipf.open("ps_map.json") as f:
                        return json.load(f)
        except zipfile.BadZipFile:
            print(f"Warning: ZIP file {zip_path} is corrupt. Rebuilding ps_map.json...")

    response = safe_get(wrapper, FIR_DOWNLOAD_URL, headers=HEADERS)
    soup = BeautifulSoup(response.text, "html.parser")
    select_tag = soup.find("select", {"name": "polstation"})
    if not select_tag:
        raise RuntimeError("Police station select element not found on page")

    ps_map = {}
    for opt in select_tag.find_all("option"):
        name = opt.text.strip()
        value = opt.get("value", "").strip()
        if not value or value.upper() == "ALL":
            continue
        ps_map[value] = {"full_code": value, "name": name}

    if zip_path:
        try:
            with zipfile.ZipFile(zip_path, 'a', zipfile.ZIP_DEFLATED) as zipf:
                zipf.writestr("ps_map.json", json.dumps(ps_map, indent=2))
        except Exception as e:
            print(f"Failed to write ps_map.json into ZIP: {e}")

    return ps_map

def download_firs(wrapper, year, police_station_code, output_zip, thread_count=1, force_download=False):
    zip_lock = Lock()
    ps_map = load_or_create_ps_map(wrapper, output_zip)

    if police_station_code.lower() == "all":
        selected_stations = [(code, info["name"]) for code, info in ps_map.items()]
        print(f"Downloading FIRs for ALL police stations ({len(selected_stations)} stations)")
    else:
        if police_station_code not in ps_map:
            raise ValueError(f"Police station code '{police_station_code}' not found.")
        ps = ps_map[police_station_code]
        selected_stations = [(ps["full_code"], ps["name"])]

    if not os.path.exists(output_zip):
        with zipfile.ZipFile(output_zip, 'w') as zf:
            pass

    def process_station(ps_value, ps_name_clean):
        wrapper_local = SessionWrapper()
        try:
            for month in range(1, 13):
                today = date.today()
                from_date = date(year, month, 1)
                last_day = calendar.monthrange(year, month)[1]
                to_date = min(date(year, month, last_day), today)

                if from_date > today:
                    print(f"Skipping future month {month:02d} of {year} for {ps_name_clean}")
                    continue

                from_date_str = from_date.strftime("%Y-%m-%d")
                to_date_str = to_date.strftime("%Y-%m-%d")

                done_marker = f"{ps_name_clean}/{year}/month_{month:02d}_done.txt"
                empty_marker = f"{ps_name_clean}/{year}/month_{month:02d}_no_firs.txt"

                with zip_lock:
                    with zipfile.ZipFile(output_zip, 'r') as zf:
                        if not force_download and (done_marker in zf.namelist() or empty_marker in zf.namelist()):
                            print(f"Skipping month {month:02d} of {year} for {ps_name_clean} (already processed)")
                            continue
                print(f"Processing month {month:02d} of {year} for {ps_name_clean}")
                payload = {
                    "polstation": ps_value,
                    "firno": "",
                    "cmplnname": "",
                    "fromdate": from_date_str,
                    "firdateupto": to_date_str,
                    "search": "Submit"
                }

                response = safe_post(wrapper_local, SEARCH_URL, data=payload, headers=HEADERS)
                soup = BeautifulSoup(response.text, "html.parser")
                table = soup.find("table")

                if not table:
                    print(f"No FIR table found for {ps_name_clean} in {month:02d}-{year}")
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, 'a', zipfile.ZIP_DEFLATED) as zf:
                            zf.writestr(empty_marker, "No data\n")
                    continue

                rows = table.find_all("tr")[1:]
                month_files = []

                for row in rows:
                    cols = row.find_all(['td', 'th'])
                    if len(cols) < 2:
                        continue

                    fir_no = cols[1].text.strip()

                    file_token = cols[-1].find("a")
                    if not file_token:
                        continue

                    raw_url = file_token.get("href", "").strip()
                    if not raw_url:
                        continue

                    pdf_url = raw_url if raw_url.startswith("http") else urljoin(BASE_URL, raw_url)

                    if '/' in fir_no:
                        fir_no_parts = fir_no.split('/')
                        safe_fir_no = fir_no_parts[0]  
                    else:
                        safe_fir_no = fir_no 

                    zip_path = f"{ps_name_clean}/{year}/{safe_fir_no}.pdf"

                    with zip_lock:
                        with zipfile.ZipFile(output_zip, 'r') as zf:
                            already_exists = zip_path in zf.namelist()

                    if not already_exists:
                        pdf_response = safe_get(wrapper, pdf_url, headers=HEADERS)
                        if pdf_response.status_code == 200:
                            month_files.append((zip_path, pdf_response.content))
                            print(f"Downloaded FIR {fir_no}")
                    else:
                        print(f"Already Downloaded FIR {fir_no}")

                if month_files:
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, 'a', zipfile.ZIP_DEFLATED) as zipf:
                            for zip_path, content in month_files:
                                zipf.writestr(zip_path, content)
                            zipf.writestr(done_marker, f"Completed FIR download for {ps_name_clean} in {year}-{month:02d} on {datetime.now().isoformat()}")

            return 1

        except KeyboardInterrupt:
            print(f"\nInterrupted {ps_name_clean}")
            return 0

    if thread_count > 1:
        with ThreadPoolExecutor(max_workers=thread_count) as executor:
            for ps_value, ps_name_clean in selected_stations:
                executor.submit(process_station, ps_value, ps_name_clean)
    else:
        for ps_value, ps_name_clean in selected_stations:
            ret = process_station(ps_value, ps_name_clean)
            if ret == 0:
                print("\nDownload interrupted by user. Exiting gracefully.")
                sys.exit(0)

def main():
    parser = argparse.ArgumentParser(
        description="Download FIRs from Bidhannagar Police FIR Portal.\n\n"
                    "Actions:\n"
                    "  download     - Downloads FIRs for given station/year\n"
                    "  force        - Forces re-download\n"
                    "  listps       - Lists all police station codes and names\n",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument("action", type=str, choices=["download", "force", "listps"], nargs="?", default="download", help="Action to perform: download, force, listps")
    parser.add_argument("year", type=int, nargs="?", help="Year for FIRs")
    parser.add_argument("pscode", type=str, nargs="?", help="Police station code OR 'all'")
    parser.add_argument("output", type=str, nargs="?", help="Output ZIP file")
    args = parser.parse_args()

    wrapper = SessionWrapper()
    if not args.output:
        print("Output ZIP file is required for all actions.")
        return

    ps_map = load_or_create_ps_map(wrapper, args.output if args.output else None)

    if args.action == "listps":
        for code, info in ps_map.items():
            print(f"{code}: {info['name']}")
        print("\nUse 'all' to download from ALL police stations.")
        return

    if args.action in ["download", "force"]:
        if not all([args.year, args.pscode, args.output]):
            print("Year, police station code, and output ZIP are required.")
            return

        try:
            download_firs(
                wrapper=wrapper,
                year=args.year,
                police_station_code=args.pscode,
                output_zip=args.output,
                thread_count=1,
                force_download=(args.action == "force")
            )
        except KeyboardInterrupt:
            print("\nInterrupted by user. Exiting gracefully...")
            sys.exit(0)

if __name__ == "__main__":
    main()
