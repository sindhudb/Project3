
import argparse
import calendar
import os
import zipfile
from io import BytesIO
from datetime import datetime
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from PIL import Image
import pytesseract

import json
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, date
from threading import Lock
import sys
import time
import random
from requests.exceptions import SSLError, ConnectionError, RequestException
from http.client import IncompleteRead, RemoteDisconnected
from urllib3.exceptions import ProtocolError
import pytesseract

pytesseract.pytesseract.tesseract_cmd = r"C:\\Users\\dhi_intern4\\AppData\\Local\\Programs\\Tesseract-OCR\\tesseract.exe"


# Constants
BASE_URL = "https://bondhu.kolkatapolice.org"
FIR_DOWNLOAD_URL = BASE_URL + "/download_fir"
SEARCH_URL = BASE_URL + "/getSearchFirResult"
PDF_DOWNLOAD_URL = BASE_URL + "/downloadPdf/"
HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

class SessionWrapper:
    def __init__(self):
        self.session = requests.Session()

def simulate_human_delay(min_delay=1.5, max_delay=3.5):
    time.sleep(random.uniform(min_delay, max_delay))

def safe_get(wrapper, url, headers=None, params=None, max_retries=3, timeout=10):
    for attempt in range(max_retries):
        try:
            response = wrapper.session.get(url, headers=headers, params=params, timeout=timeout)
            response.raise_for_status()
            simulate_human_delay()
            return response
        except (SSLError, ConnectionError, IncompleteRead, RemoteDisconnected, ProtocolError, RequestException) as e:
            print(f"[GET] Attempt {attempt+1} failed: {e}")
            wrapper.session = requests.Session()  # Reinitialize session
            time.sleep(2 ** attempt + random.uniform(0, 0.5))
    raise RuntimeError(f"[GET] Failed to fetch {url} after {max_retries} attempts")

def safe_post(wrapper, url, data=None, headers=None, max_retries=3, timeout=10):
    for attempt in range(max_retries):
        try:
            response = wrapper.session.post(url, data=data, headers=headers, timeout=timeout)
            response.raise_for_status()
            simulate_human_delay()
            return response
        except (SSLError, ConnectionError, IncompleteRead, RemoteDisconnected, ProtocolError, RequestException) as e:
            print(f"[POST] Attempt {attempt+1} failed: {e}")
            wrapper.session = requests.Session()  # Reinitialize session
            time.sleep(2 ** attempt + random.uniform(0, 0.5))
    raise RuntimeError(f"[POST] Failed to post to {url} after {max_retries} attempts")


def fetch_police_stations_by_division(wrapper, full_divcode):
    # Step 1: GET main page to establish session and extract CSRF
    response = safe_get(wrapper, FIR_DOWNLOAD_URL, headers=HEADERS)
    soup = BeautifulSoup(response.text, "html.parser")

    csrf_token = soup.find("meta", {"name": "csrf-token"})["content"]
    xsrf_token = wrapper.session.cookies.get("XSRF-TOKEN")

    # Step 2: Prepare headers and payload
    headers = HEADERS.copy()
    headers.update({
        "Referer": FIR_DOWNLOAD_URL,
        "Origin": BASE_URL,
        "X-CSRF-TOKEN": csrf_token,
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
    })

    payload = {
        "divcode": full_divcode,
        "selected_ps": ""
    }

    # Step 3: POST to getPsByDivcode
    response = safe_post(wrapper, BASE_URL + "/getPsByDivcode", data=payload, headers=headers)

    # Step 4: Parse response
    soup = BeautifulSoup(response.text, "html.parser")
    options = soup.find_all("option")

    ps_map = {}
    for option in options:
        value = option.get("value", "")
        if "|" in value:
            short_ps = value.split("|")[0]
            ps_map[short_ps] = {
                "full_code": value,
                "name": option.text.strip()
            }

    return ps_map

def load_or_create_ps_map(wrapper, zip_path):
    import json

    # Try loading from ZIP
    if zip_path and os.path.exists(zip_path):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                if "ps_map.json" in zipf.namelist():
                    with zipf.open("ps_map.json") as f:
                        return json.load(f)
        except zipfile.BadZipFile:
            print(f"Warning: ZIP file {zip_path} is corrupt. Rebuilding ps_map.json...")

    # Rebuild from scratch
    response = safe_get(wrapper, FIR_DOWNLOAD_URL, headers=HEADERS)
    soup = BeautifulSoup(response.text, "html.parser")
    div_select = soup.find("select", {"id": "divcode"})
    division_map = {
        option["value"].split("|")[0]: option["value"]
        for option in div_select.find_all("option") if "|" in option["value"]
    }

    ps_map = {}
    for short_div, full_div in division_map.items():
        try:
            stations = fetch_police_stations_by_division(wrapper, full_div)
            ps_map[short_div] = {
                "full_code": full_div,
                "stations": stations
            }
        except Exception as e:
            print(f"Failed to fetch police stations for division {short_div}: {e}")
            continue

    # Write ps_map.json into the ZIP
    if zip_path:
        try:
            with zipfile.ZipFile(zip_path, 'a', zipfile.ZIP_DEFLATED) as zipf:
                zipf.writestr("ps_map.json", json.dumps(ps_map, indent=2))
        except Exception as e:
            print(f"Failed to write ps_map.json into ZIP: {e}")

    return ps_map

def get_csrf_and_captcha(wrapper):
    response = safe_get(wrapper, FIR_DOWNLOAD_URL, headers=HEADERS)
    soup = BeautifulSoup(response.text, "html.parser")

    # Extract CSRF token
    csrf_token = soup.find("meta", {"name": "csrf-token"})["content"]

    # Find the <span id="captcha"> and then the <img> inside it
    captcha_span = soup.find("span", {"id": "captcha"})
    captcha_img_tag = captcha_span.find("img") if captcha_span else None

    if not captcha_img_tag or not captcha_img_tag.get("src"):
        raise ValueError("Captcha image not found in the expected location.")

    # Build full image URL
    captcha_img_url = urljoin(BASE_URL, captcha_img_tag["src"])

    # Download and process the captcha image
    captcha_response = safe_get(wrapper, captcha_img_url, headers=HEADERS)
    captcha_img = Image.open(BytesIO(captcha_response.content))
    captcha_text = pytesseract.image_to_string(captcha_img).strip()
    captcha_text = ''.join(filter(str.isalnum, captcha_text))

    return csrf_token, captcha_text


def download_firs(wrapper, year, division_code, police_station_code, output_zip, thread_count=1, force_download=False):
    zip_lock = Lock()
    ps_map = load_or_create_ps_map(wrapper, output_zip)

    if division_code == 'all':
        division_codes = list(ps_map.keys())
    else:
        if division_code not in ps_map:
            raise ValueError(f"Division code '{division_code}' not found.")
        division_codes = [division_code]

    def process_station(full_divcode, full_psname, ps_name_clean):
        wrapper = SessionWrapper()  # Fresh session per station

        try:
            for month in range(1, 13):
                today = date.today()
                from_date = date(year, month, 1)
                last_day = calendar.monthrange(year, month)[1]
                to_date = min(date(year, month, last_day), today)

                if from_date > today:
                    print(f"Skipping future month {month:02d} of {year} for {ps_name_clean}")
                    return

                from_date_str = from_date.strftime("%Y-%m-%d")
                to_date_str = to_date.strftime("%Y-%m-%d")

                done_marker = f"{ps_name_clean}/{year}/month_{month:02d}_done.txt"
                empty_marker = f"{ps_name_clean}/{year}/month_{month:02d}_no_firs.txt"

                with zip_lock:
                    with zipfile.ZipFile(output_zip, 'r') as zf:
                        if not force_download and (done_marker in zf.namelist() or empty_marker in zf.namelist()):
                            print(f"Skipping month {month:02d} of {year} for {ps_name_clean} (already processed)")
                            continue

                print(f"Processing month {month:02d} of {year} for {ps_name_clean}")
                csrf_token, captcha_text = get_csrf_and_captcha(wrapper)

                payload = {
                    "_token": csrf_token,
                    "divcode": full_divcode,
                    "psname": full_psname,
                    "from_date": from_date_str,
                    "to_date": to_date_str,
                    "firno": "",
                    "captcha": captcha_text
                }

                response = safe_post(wrapper, SEARCH_URL, data=payload, headers=HEADERS)
                soup = BeautifulSoup(response.text, "html.parser")
                firlist_div = soup.find("div", class_="firlist")
                if not firlist_div:
                    print(f"No FIR result container found for {ps_name_clean} from {from_date_str} to {to_date_str}")
                    continue

                if firlist_div.find("h2", string=lambda s: s and "No Data Found" in s):
                    print(f"No FIRs found for {ps_name_clean} from {from_date_str} to {to_date_str}")
                    marker_content = f"No FIRs found for {ps_name_clean} in {year}-{month:02d}\nChecked on {datetime.now().isoformat()}"
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, 'a', zipfile.ZIP_DEFLATED) as zipf:
                            zipf.writestr(empty_marker, marker_content)
                    continue

                table = firlist_div.find("table", {"id": "simpletableforshopbar"})
                if not table:
                    print(f"FIR table missing for {ps_name_clean} from {from_date_str} to {to_date_str}")
                    continue

                rows = table.find_all("tr")[1:]
                month_files = []
                for row in rows:
                    cols = row.find_all("td")
                    if len(cols) < 4:
                        continue
                    fir_no = cols[0].text.strip()
                    file_token = cols[3].find("button")["value"]
                    pdf_url = PDF_DOWNLOAD_URL + file_token

                    zip_path = f"{ps_name_clean}/{year}/{fir_no}.pdf"
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, 'r') as zf:
                            already_exists = zip_path in zf.namelist()
                    if not already_exists:
                        pdf_response = safe_get(wrapper, pdf_url, headers=HEADERS)
                        if pdf_response.status_code == 200:
                            month_files.append((zip_path, pdf_response.content))
                            print(f"Downloaded FIR {fir_no}")
                    else:
                        print(f"Already Downloaded FIR {fir_no}")

                if month_files:
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, 'a', zipfile.ZIP_DEFLATED) as zipf:
                            for zip_path, content in month_files:
                                zipf.writestr(zip_path, content)
                            zipf.writestr(done_marker, f"Completed FIR download for {ps_name_clean} in {year}-{month:02d} on {datetime.now().isoformat()}")
                return 1
        except KeyboardInterrupt:
            print(f"\nInterrupted while processing {ps_name_clean}. Skipping station.")
            return 0

    try:
        for divcode in division_codes:
            division_data = ps_map[divcode]
            full_divcode = division_data["full_code"]
            station_map = division_data["stations"]

            if police_station_code == 'all':
                police_stations = [(info["full_code"], info["name"]) for info in station_map.values()]
            else:
                if police_station_code not in station_map:
                    raise ValueError(f"Police station code '{police_station_code}' not found in division '{divcode}'.")
                info = station_map[police_station_code]
                police_stations = [(info["full_code"], info["name"])]

            if thread_count > 1:
                with ThreadPoolExecutor(max_workers=thread_count) as executor:
                    for full_psname, ps_name_clean in police_stations:
                        executor.submit(process_station, full_divcode, full_psname, ps_name_clean)
            else:
                for full_psname, ps_name_clean in police_stations:
                    ret = process_station(full_divcode, full_psname, ps_name_clean)
                    if ret == 0 :
                        print("\nDownload interrupted by user. Exiting gracefully.")
                        sys.exit(0)

    except KeyboardInterrupt:
        print("\nDownload interrupted by user. Exiting gracefully.")
        sys.exit(0)

def main():
    parser = argparse.ArgumentParser(
        description="Download FIRs from Kolkata Police FIR Portal.\n\n"
                    "Actions:\n"
                    "  download     (default) - Downloads FIRs for given division/station/year if not already attempted\n"
                    "  force        - Forces download even if previously attempted; skips existing files\n"
                    "  listdivision - Lists all division codes and their full codes\n"
                    "  listps       - Lists all police station codes and names for a given division\n",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument("action", type=str, choices=["download", "force", "listdivision", "listps"], nargs="?", default="download",
                        help="Action to perform: download, force, listdivision, listps")
    parser.add_argument("year", type=int, nargs="?", help="Year for FIRs (required for download/force)")
    parser.add_argument("division", type=str, nargs="?", help="Division code (e.g., ND or 'all')")
    parser.add_argument("pscode", type=str, nargs="?", help="Police station code (e.g., F or 'all')")
    parser.add_argument("output", type=str, nargs="?", help="Output ZIP file path")
    args = parser.parse_args()

    wrapper = SessionWrapper()

    # Load or create ps_map from ZIP
    if not args.output:
        print("Output ZIP file is required for all actions.")
        return

    ps_map = load_or_create_ps_map(wrapper, args.output)

    # Action: listdivision
    if args.action == "listdivision":
        for divcode, data in ps_map.items():
            print(f"{divcode}: {data['full_code']}")
        return

    # Action: listps
    if args.action == "listps":
        if not args.division or args.division not in ps_map:
            print("Please provide a valid division code for 'listps'")
            return
        for short_ps, info in ps_map[args.division]["stations"].items():
            print(f"{short_ps}: {info['full_code']} ({info['name']})")
        return

    # Action: download or force
    if args.action in ["download", "force"]:
        if not all([args.year, args.division, args.pscode, args.output]):
            print("Year, division, pscode, and output ZIP are required for download/force actions.")
            return
        try:
            download_firs(
                wrapper=wrapper,
                year=args.year,
                division_code=args.division,
                police_station_code=args.pscode,
                output_zip=args.output,
                thread_count=1,
                force_download=(args.action == "force")
            )
        except KeyboardInterrupt:
            print("\nInterrupted by user. Exiting gracefully...")
            sys.exit(0)

if __name__ == "__main__":
    main()