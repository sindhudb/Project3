import argparse
import calendar
import os
import zipfile
from io import BytesIO
from datetime import datetime, date
from urllib.parse import urljoin
import random
import sys
import time
from threading import Lock
from concurrent.futures import ThreadPoolExecutor

import requests
from requests.exceptions import SSLError, ConnectionError, RequestException
from http.client import IncompleteRead, RemoteDisconnected
from urllib3.exceptions import ProtocolError

from bs4 import BeautifulSoup
from PIL import Image
import pytesseract
import json

# ---------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------
BASE_URL = "https://siliguripc.wbpolice.gov.in"
FIR_DOWNLOAD_URL = BASE_URL + "/fir"
SEARCH_URL = BASE_URL + "/fir.php"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": FIR_DOWNLOAD_URL
}

# ---------------------------------------------------------
# SESSION WRAPPER
# ---------------------------------------------------------
class SessionWrapper:
    def __init__(self):
        self.session = requests.Session()

# ---------------------------------------------------------
# SAFE REQUESTS
# ---------------------------------------------------------
def simulate_human_delay(min_delay=1.5, max_delay=3.5):
    time.sleep(random.uniform(min_delay, max_delay))

def safe_get(wrapper, url, headers=None, params=None, max_retries=3, timeout=10):
    for attempt in range(max_retries):
        try:
            response = wrapper.session.get(url, headers=headers, params=params, timeout=timeout)
            response.raise_for_status()
            simulate_human_delay()
            return response
        except (SSLError, ConnectionError, IncompleteRead, RemoteDisconnected, ProtocolError, RequestException) as e:
            print(f"[GET] Attempt {attempt+1} failed: {e}")
            wrapper.session = requests.Session()
            time.sleep(2 ** attempt + random.uniform(0, 0.5))
    raise RuntimeError(f"[GET] Failed to fetch {url} after {max_retries} attempts")

def safe_post(wrapper, url, data=None, headers=None, max_retries=3, timeout=10):
    for attempt in range(max_retries):
        try:
            response = wrapper.session.post(url, data=data, headers=headers, timeout=timeout)
            response.raise_for_status()
            simulate_human_delay()
            return response
        except (SSLError, ConnectionError, IncompleteRead, RemoteDisconnected, ProtocolError, RequestException) as e:
            print(f"[POST] Attempt {attempt+1} failed: {e}")
            wrapper.session = requests.Session()
            time.sleep(2 ** attempt + random.uniform(0, 0.5))
    raise RuntimeError(f"[POST] Failed to post to {url} after {max_retries} attempts")

# ---------------------------------------------------------
# LOAD POLICE STATION MAP
# ---------------------------------------------------------
def load_or_create_ps_map(wrapper, zip_path):
    if zip_path and os.path.exists(zip_path):
        try:
            with zipfile.ZipFile(zip_path, "r") as zipf:
                if "ps_map.json" in zipf.namelist():
                    with zipf.open("ps_map.json") as f:
                        return json.loads(f.read())
        except zipfile.BadZipFile:
            print(f"Warning: ZIP file {zip_path} is corrupt. Rebuilding ps_map.json...")

    response = safe_get(wrapper, FIR_DOWNLOAD_URL, headers=HEADERS)
    soup = BeautifulSoup(response.text, "html.parser")
    select_tag = soup.find("select", {"name": "psid"})
    if not select_tag:
        raise RuntimeError("Cannot locate police station dropdown (psid).")

    ps_map = {}
    for opt in select_tag.find_all("option"):
        value = opt.get("value", "").strip()
        name = opt.text.strip()
        if not value or value.lower() == "all":
            continue
        ps_map[value] = {"full_code": value, "name": name}

    if zip_path:
        try:
            with zipfile.ZipFile(zip_path, "a", zipfile.ZIP_DEFLATED) as zipf:
                zipf.writestr("ps_map.json", json.dumps(ps_map, indent=2))
        except Exception as e:
            print(f"Failed to write ps_map.json into ZIP: {e}")

    return ps_map

# ---------------------------------------------------------
# DOWNLOAD FIRs
# ---------------------------------------------------------
def download_firs(wrapper, year, police_station_code, output_zip, thread_count=1, force_download=False):
    zip_lock = Lock()
    ps_map = load_or_create_ps_map(wrapper, output_zip)

    if police_station_code.lower() == "all":
        stations = [(code, info["name"]) for code, info in ps_map.items()]
    else:
        if police_station_code not in ps_map:
            raise ValueError("Invalid police station code")
        ps = ps_map[police_station_code]
        stations = [(ps["full_code"], ps["name"])]

    if not os.path.exists(output_zip):
        with zipfile.ZipFile(output_zip, "w"):
            pass

    def process_station(psid, psname):
        local_wrapper = SessionWrapper()

        try:
            for month in range(1, 13):
                today = date.today()
                from_date = date(year, month, 1)
                last_day = calendar.monthrange(year, month)[1]
                to_date = min(date(year, month, last_day), today)
                if from_date > today:
                    print(f"Skipping future month {month} for {psname}")
                    continue

                from_s = from_date.strftime("%Y-%m-%d")
                to_s = to_date.strftime("%Y-%m-%d")
                done_marker = f"{psname}/{year}/month_{month:02d}_done.txt"
                empty_marker = f"{psname}/{year}/month_{month:02d}_no_firs.txt"

                with zip_lock:
                    with zipfile.ZipFile(output_zip, "r") as zf:
                        if not force_download and (done_marker in zf.namelist() or empty_marker in zf.namelist()):
                            print(f"Skipping {psname} {month:02d} — already done")
                            continue

                print(f"Processing month {month:02d} of {year} for {psname}")

                payload = {
                    "psid": psid,
                    "fromdate": from_s,
                    "todate": to_s,
                    "Search": "Search"
                }

                response = safe_post(local_wrapper, SEARCH_URL, data=payload, headers=HEADERS)
                soup = BeautifulSoup(response.text, "html.parser")

                table = soup.find("table")
                if not table or len(table.find_all("tr")) <= 1:
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, "a") as zf:
                            zf.writestr(empty_marker, "No FIRs\n")
                    print(f"NO DATA for {psname} Month {month}")
                    continue

                rows = table.find_all("tr")[1:]
                month_files = []
                for row in rows:
                    cols = row.find_all("td")
                    if len(cols) < 2:
                        continue
                    fir_no = cols[0].text.strip()
                    file_token = cols[1].find_all("a")

                    for link in file_token:
                        href = link.get("href", "")
                        if not href:
                            continue
                        pdf_url = urljoin(BASE_URL, href)
                        safe_name = fir_no.replace("/", "_")
                        zip_path = f"{psname}/{year}/{safe_name}.pdf"

                        with zip_lock:
                            with zipfile.ZipFile(output_zip, 'r') as zf:
                                already_exists = zip_path in zf.namelist()
                        if not already_exists:
                            pdf_response = safe_get(local_wrapper, pdf_url, headers=HEADERS)
                            if pdf_response.status_code == 200:
                                month_files.append((zip_path, pdf_response.content))
                                print(f"Downloaded FIR {fir_no}")
                        else:
                            print(f"Already Downloaded FIR {fir_no}")

                if month_files:
                    with zip_lock:
                        with zipfile.ZipFile(output_zip, "a", zipfile.ZIP_DEFLATED) as zipf:
                            for zip_path, content in month_files:
                                zipf.writestr(zip_path, content)
                            zipf.writestr(done_marker, f"Completed FIR download for {psname} in {year}-{month:02d} on {datetime.now().isoformat()}")

            return 1

        except KeyboardInterrupt:
            print(f"\nInterrupted while processing {psname}. Skipping station.")
            return 0

    # Run stations with threads
    if thread_count > 1:
        with ThreadPoolExecutor(max_workers=thread_count) as pool:
            futures = []
            for psid, psname in stations:
                futures.append(pool.submit(process_station, psid, psname))
            for future in futures:
                try:
                    future.result()
                except KeyboardInterrupt:
                    print("\nDownload interrupted by user. Exiting gracefully.")
                    sys.exit(0)
    else:
        for psid, psname in stations:
            ret = process_station(psid, psname)
            if ret == 0:
                print("\nDownload interrupted by user. Exiting gracefully.")
                sys.exit(0)

# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["download", "force", "listps"])
    parser.add_argument("year", type=int, nargs="?")
    parser.add_argument("pscode", type=str, nargs="?")
    parser.add_argument("output", type=str, nargs="?")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()

    wrapper = SessionWrapper()

    if not args.output:
        print("Output ZIP file is required for all actions.")
        return

    ps_map = load_or_create_ps_map(wrapper, args.output)

    if args.action == "listps":
        print("Available police stations:")
        for code, info in ps_map.items():
            print(f"{code}: {info['name']}")
        print("\nUse 'all' to download from all stations.")
        return

    if args.action in ["download", "force"]:
        if not all([args.year, args.pscode, args.output]):
            print("Year, police station code, and output ZIP are required for download/force.")
            return
        try:
            download_firs(
                wrapper=wrapper,
                year=args.year,
                police_station_code=args.pscode,
                output_zip=args.output,
                thread_count=args.threads,
                force_download=(args.action == "force")
            )
        except KeyboardInterrupt:
            print("\nInterrupted by user. Exiting gracefully...")
            sys.exit(0)

if __name__ == "__main__":
    main()
